Make sure all the paths present in constant.py file is correct (change accordingly)

To use RM1/RM3 model, set the BATCH_SEARCH_MODEL to the appropriate one in constants.py

Set the number of retrieved docs, feedback docs, feedback terms, orginial weight in the constants.py (set the appropriate BATCH_SEARCH_* variable)